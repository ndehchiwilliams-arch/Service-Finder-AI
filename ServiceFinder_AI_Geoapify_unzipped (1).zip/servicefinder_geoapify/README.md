# ServiceFinder AI — Geoapify edition

This version replaces Google Places with Geoapify for worldwide service discovery.

## What it does
- Accepts a service such as plumber, electrician, mechanic, doctor, lawyer, tutor, restaurant, hotel, cleaner, etc.
- Accepts a city/country such as Douala, Cameroon or Paris, France.
- Uses Geoapify Geocoding to resolve the requested city.
- Uses Geoapify Places to search inside the city boundary.
- Uses Geoapify Place Details to retrieve phone numbers and websites when those details exist in the underlying data.
- Provides map links, addresses and approximate distance when available.
- Works on phones and computers.

Geoapify's current documentation says the Places API requires an API key, supports category and geographic searches, and its free plan includes 3,000 credits/day without requiring a credit card. Places results can include a `place_id`, which can be used with Place Details for additional information such as contact data and websites.

## IMPORTANT PAYMENT NOTE
The page displays a 1,000 FCFA ServiceFinder AI access fee and the owner's MTN Mobile Money number 678831860. This starter package does NOT automatically verify MTN Mobile Money payments. Do not launch it as a paid service until an official payment gateway/API and server-side verification are connected.

## Cloudflare Pages deployment
1. Create a GitHub repository and upload all files.
2. In Cloudflare Pages, import the GitHub repository.
3. Build command: `exit 0`
4. Build output directory: `/`
5. Add a secret/environment variable:
   `GEOAPIFY_API_KEY` = your Geoapify project API key
6. Deploy.

Keep the API key only in the server environment. Do not put it in `app.js` or `index.html`.

## Notes on search quality
Geoapify Places is category-based. This build maps common service words to broad Geoapify categories and ranks matching names/categories higher. For uncommon services, it falls back to the broad `service` category. The underlying place data comes from OpenStreetMap and can be incomplete or outdated for some businesses; provider availability, phone numbers, websites and credentials should always be verified.

## Production upgrades
- Real payment checkout + webhook verification
- User accounts / paid search credits
- Better AI service-to-category classification
- Nearby / GPS search
- Provider claim and verification system
- WhatsApp/contact options where available
- Multi-language and multi-currency payments
- Privacy, terms, refunds and provider disclaimers
- Rate limiting and abuse protection
