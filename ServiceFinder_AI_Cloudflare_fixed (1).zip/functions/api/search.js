const SERVICE_MAP = {
  plumber: ["service"],
  plumbing: ["service"],
  electrician: ["service"],
  electrical: ["service"],
  mechanic: ["service"],
  repair: ["service"],
  cleaner: ["service"],
  cleaning: ["service"],
  carpenter: ["service"],
  locksmith: ["service"],
  painter: ["service"],
  roofer: ["service"],
  builder: ["service"],
  contractor: ["service"],
  tutor: ["education"],
  teacher: ["education"],
  school: ["education"],
  doctor: ["healthcare"],
  dentist: ["healthcare"],
  hospital: ["healthcare"],
  clinic: ["healthcare"],
  pharmacy: ["healthcare"],
  lawyer: ["commercial"],
  attorney: ["commercial"],
  accountant: ["commercial"],
  insurance: ["commercial"],
  restaurant: ["catering"],
  cafe: ["catering"],
  hotel: ["accommodation"],
  hostel: ["accommodation"],
  car: ["service"],
  taxi: ["service"],
  transport: ["service"],
  salon: ["service"],
  barber: ["service"],
  beauty: ["service"],
  laundry: ["service"],
  tailor: ["service"],
  photographer: ["service"],
  wedding: ["service"],
  fitness: ["sport"],
  gym: ["sport"],
  "personal trainer": ["sport"]
};

function categoriesFor(service) {
  const s = service.toLowerCase().trim();
  for (const [term, categories] of Object.entries(SERVICE_MAP)) {
    if (s === term || s.includes(term)) return categories;
  }
  return ["service"];
}

async function geoFetch(url) {
  const response = await fetch(url);
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const message = data?.error?.message || data?.message || `Geoapify request failed (${response.status})`;
    throw new Error(message);
  }

  return data;
}

export async function onRequestGet({ request, env }) {
  const requestUrl = new URL(request.url);
  const service = requestUrl.searchParams.get("service")?.trim();
  const location = requestUrl.searchParams.get("location")?.trim();

  if (!service || !location) {
    return Response.json(
      { error: "Please enter both a service and a location." },
      { status: 400 }
    );
  }

  if (!env?.GEOAPIFY_API_KEY) {
    return Response.json(
      { error: "GEOAPIFY_API_KEY is not configured in Cloudflare." },
      { status: 500 }
    );
  }

  try {
    // Resolve the requested city/location first.
    const geocodeUrl = new URL("https://api.geoapify.com/v1/geocode/search");
    geocodeUrl.searchParams.set("text", location);
    geocodeUrl.searchParams.set("limit", "1");
    geocodeUrl.searchParams.set("format", "json");
    geocodeUrl.searchParams.set("apiKey", env.GEOAPIFY_API_KEY);

    const geocode = await geoFetch(geocodeUrl);
    const place = geocode.results?.[0];

    if (!place) {
      return Response.json(
        {
          error: `I could not locate "${location}". Try a city and country, for example "Douala, Cameroon".`
        },
        { status: 404 }
      );
    }

    // Search within the resolved place. Geoapify's place_id filter keeps
    // results focused on the requested city/area.
    const placesUrl = new URL("https://api.geoapify.com/v2/places");
    placesUrl.searchParams.set("categories", categoriesFor(service).join(","));
    placesUrl.searchParams.set("filter", `place:${place.place_id}`);
    placesUrl.searchParams.set("limit", "20");
    placesUrl.searchParams.set("lang", "en");
    placesUrl.searchParams.set("apiKey", env.GEOAPIFY_API_KEY);

    const places = await geoFetch(placesUrl);
    const features = Array.isArray(places.features) ? places.features : [];
    const serviceWords = service
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .filter(Boolean);

    const ranked = features
      .map((feature) => {
        const properties = feature?.properties || {};
        const haystack = [
          properties.name,
          properties.formatted,
          ...(Array.isArray(properties.categories) ? properties.categories : [])
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();

        const keywordHits = serviceWords.reduce(
          (score, word) => score + (haystack.includes(word) ? 1 : 0),
          0
        );

        return {
          properties,
          score: keywordHits * 100 - (Number(properties.distance) || 0) / 10000
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);

    const results = await Promise.all(
      ranked.map(async ({ properties }) => {
        let details = {};

        if (properties.place_id) {
          try {
            const detailsUrl = new URL("https://api.geoapify.com/v2/place-details");
            detailsUrl.searchParams.set("id", properties.place_id);
            detailsUrl.searchParams.set("apiKey", env.GEOAPIFY_API_KEY);

            const detailResponse = await geoFetch(detailsUrl);
            const detailFeature = detailResponse.features?.find(
              (feature) => feature?.properties?.feature_type === "details"
            );
            details = detailFeature?.properties || {};
          } catch (_) {
            // Details are optional; keep the basic place result if enrichment fails.
          }
        }

        const lat = properties.lat ?? details.lat;
        const lon = properties.lon ?? details.lon;
        const maps =
          lat != null && lon != null
            ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${lat},${lon}`)}`
            : "";

        return {
          name: properties.name || details.name || "Unnamed provider",
          address: properties.formatted || details.formatted || "Address unavailable",
          phone:
            details.contact?.phone ||
            details.contact?.phone_international?.[details.country_code] ||
            "",
          website: details.website || details.website_other?.[0] || "",
          maps,
          distance: Number(properties.distance) || 0,
          categories: Array.isArray(properties.categories) ? properties.categories : []
        };
      })
    );

    return Response.json({
      service,
      location,
      resolvedLocation: place.formatted || location,
      results,
      source: "Geoapify"
    });
  } catch (error) {
    return Response.json(
      { error: error?.message || "Geoapify search failed." },
      { status: 502 }
    );
  }
}
