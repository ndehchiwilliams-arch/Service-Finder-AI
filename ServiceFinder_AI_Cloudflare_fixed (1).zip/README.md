# ServiceFinder AI + Geoapify + Cloudflare Pages

A lightweight static ServiceFinder AI website with a Cloudflare Pages Function at `/api/search`.

## Cloudflare Pages settings

For a GitHub-connected Pages project:

- Production branch: `main`
- Framework preset: None
- Build command: `exit 0`
- Build output directory: `.`
- Root directory: `/` (unless these files are inside a subfolder in GitHub)

If Cloudflare lets you leave the Build command blank for a no-build project, that is also supported. Do not enter `0` — `0` is not a shell command and causes `/bin/sh: 0: not found`.

## Required secret

In Cloudflare Pages:

**Settings → Variables and Secrets → Add**

Create a production secret named:

`GEOAPIFY_API_KEY`

Set its value to your Geoapify API key. Do not put the API key in `app.js`, `index.html`, or GitHub.

## Repository structure

The repository root should contain:

```
index.html
app.js
style.css
README.md
functions/
  api/
    search.js
```

The `functions` directory must be at the root of the Pages project for the `/api/search` route to be generated.

## Deploy

1. Push these files to GitHub.
2. In Cloudflare Pages, open the connected project.
3. Confirm the build settings above.
4. Add `GEOAPIFY_API_KEY` under Variables and Secrets for Production.
5. Save the settings.
6. Create a new deployment / retry deployment.
7. Open the site and test a search such as `plumber` + `Douala, Cameroon`.
