const $=id=>document.getElementById(id);
$("searchBtn").onclick=async()=>{
 const service=$("service").value.trim(), location=$("location").value.trim();
 if(!service||!location){$("status").innerHTML='<div class="error">Enter both the service and location.</div>';return}
 $("results").innerHTML=""; $("status").innerHTML='<div class="loading">Searching local providers…</div>';
 try{
  const r=await fetch(`/api/search?service=${encodeURIComponent(service)}&location=${encodeURIComponent(location)}`);
  const data=await r.json();
  if(!r.ok) throw new Error(data.error||"Search failed");
  $("status").innerHTML=`<p><b>${data.results.length}</b> provider(s) found for <b>${service}</b> in <b>${location}</b>.</p>`;
  $("results").innerHTML=data.results.map(p=>`
   <article class="card">
    <h3>${esc(p.name)}</h3>
    <div class="meta">${esc(p.address||"Address unavailable")}</div>
    ${p.distance?`<div class="meta">Approx. ${(p.distance/1000).toFixed(1)} km away</div>`:""}
    <div class="actions">
      ${p.phone?`<a href="tel:${esc(p.phone)}">Call</a>`:""}
      ${p.website?`<a href="${esc(p.website)}" target="_blank" rel="noopener">Website</a>`:""}
      ${p.maps?`<a href="${esc(p.maps)}" target="_blank" rel="noopener">Map</a>`:""}
    </div>
   </article>`).join("")||"<p>No providers found. Try a broader service or nearby city.</p>";
 }catch(e){$("status").innerHTML=`<div class="error">${esc(e.message)}</div>`}
};
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}