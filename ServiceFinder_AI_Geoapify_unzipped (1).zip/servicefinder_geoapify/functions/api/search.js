const SERVICE_MAP = {
  plumber: ["service"], plumbing: ["service"], electrician: ["service"], electrical: ["service"], mechanic: ["service"], repair: ["service"], cleaner: ["service"], cleaning: ["service"], carpenter: ["service"], locksmith: ["service"], painter: ["service"], roofer: ["service"], builder: ["service"], contractor: ["service"], tutor: ["education"], teacher: ["education"], school: ["education"], doctor: ["healthcare"], dentist: ["healthcare"], hospital: ["healthcare"], clinic: ["healthcare"], pharmacy: ["healthcare"], lawyer: ["commercial"], attorney: ["commercial"], accountant: ["commercial"], insurance: ["commercial"], restaurant: ["catering"], cafe: ["catering"], hotel: ["accommodation"], hostel: ["accommodation"], mechanic: ["service"], car: ["service"], taxi: ["service"], transport: ["service"], salon: ["service"], barber: ["service"], beauty: ["service"], laundry: ["service"], tailor: ["service"], photographer: ["service"], wedding: ["service"], fitness: ["sport"], gym: ["sport"], personal trainer: ["sport"]
};

function categoriesFor(service) {
  const s = service.toLowerCase().trim();
  for (const [term, cats] of Object.entries(SERVICE_MAP)) {
    if (s === term || s.includes(term)) return cats;
  }
  // Geoapify supports hierarchical categories. For unknown requests, service is
  // the broadest useful category and the response is ranked locally below.
  return ["service"];
}

async function geoFetch(url) {
  const r = await fetch(url);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error?.message || data.message || "Geoapify request failed");
  return data;
}

export async function onRequestGet({ request, env }) {
  const url = new URL(request.url);
  const service = url.searchParams.get("service")?.trim();
  const location = url.searchParams.get("location")?.trim();
  if (!service || !location) return Response.json({ error: "Missing service or location" }, { status: 400 });
  if (!env.GEOAPIFY_API_KEY) return Response.json({ error: "GEOAPIFY_API_KEY is not configured on the server." }, { status: 500 });

  try {
    // 1) Turn the user's city/country into a Geoapify place boundary.
    const geoUrl = new URL("https://api.geoapify.com/v1/geocode/search");
    geoUrl.searchParams.set("text", location);
    geoUrl.searchParams.set("type", "city");
    geoUrl.searchParams.set("limit", "1");
    geoUrl.searchParams.set("format", "json");
    geoUrl.searchParams.set("apiKey", env.GEOAPIFY_API_KEY);
    const geo = await geoFetch(geoUrl);
    const city = geo.results?.[0];
    if (!city) return Response.json({ error: `I could not locate "${location}". Try a city and country, such as "Douala, Cameroon".` }, { status: 404 });

    // 2) Search the city boundary using the broad service category appropriate
    // to the user's request. Geoapify supports category + place filters.
    const placesUrl = new URL("https://api.geoapify.com/v2/places");
    placesUrl.searchParams.set("categories", categoriesFor(service).join(","));
    placesUrl.searchParams.set("filter", `place:${city.place_id}`);
    placesUrl.searchParams.set("limit", "20");
    placesUrl.searchParams.set("lang", "en");
    placesUrl.searchParams.set("apiKey", env.GEOAPIFY_API_KEY);
    const places = await geoFetch(placesUrl);

    const features = places.features || [];
    const serviceWords = service.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
    const ranked = features.map(f => {
      const p = f.properties || {};
      const haystack = [p.name, p.formatted, ...(p.categories || [])].filter(Boolean).join(" ").toLowerCase();
      const keywordHits = serviceWords.reduce((n, w) => n + (haystack.includes(w) ? 1 : 0), 0);
      return { f, p, score: keywordHits * 100 - (p.distance || 0) / 10000 };
    }).sort((a,b) => b.score - a.score).slice(0, 8);

    // 3) Enrich the best matches with contact/website details.
    const results = await Promise.all(ranked.map(async ({ p }) => {
      let d = {};
      if (p.place_id) {
        try {
          const detailUrl = new URL("https://api.geoapify.com/v2/place-details");
          detailUrl.searchParams.set("id", p.place_id);
          detailUrl.searchParams.set("apiKey", env.GEOAPIFY_API_KEY);
          const detail = await geoFetch(detailUrl);
          d = detail.features?.find(x => x.properties?.feature_type === "details")?.properties || {};
        } catch (_) {}
      }
      const lat = p.lat ?? d.lat;
      const lon = p.lon ?? d.lon;
      const maps = (lat != null && lon != null) ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${lat},${lon}`)}` : "";
      return {
        name: p.name || d.name || "Unnamed provider",
        address: p.formatted || d.formatted || "Address unavailable",
        phone: d.contact?.phone || d.contact?.phone_international?.[d.country_code] || "",
        website: d.website || d.website_other?.[0] || "",
        maps,
        distance: p.distance || 0,
        categories: p.categories || []
      };
    }));

    return Response.json({
      service,
      location,
      resolvedLocation: city.formatted || location,
      results,
      source: "Geoapify"
    });
  } catch (error) {
    return Response.json({ error: error.message || "Geoapify search failed" }, { status: 502 });
  }
}
