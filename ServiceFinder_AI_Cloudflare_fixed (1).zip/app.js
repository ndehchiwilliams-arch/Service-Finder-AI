const $ = (id) => document.getElementById(id);

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[char]));
}

function safeUrl(value) {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol) ? url.href : "";
  } catch {
    return "";
  }
}

async function searchProviders() {
  const service = $("service").value.trim();
  const location = $("location").value.trim();

  if (!service || !location) {
    $("status").innerHTML = '<div class="error">Enter both the service and location.</div>';
    return;
  }

  $("results").innerHTML = "";
  $("status").innerHTML = '<div class="loading">Searching local providers…</div>';
  $("searchBtn").disabled = true;

  try {
    const endpoint = `/api/search?service=${encodeURIComponent(service)}&location=${encodeURIComponent(location)}`;
    const response = await fetch(endpoint, {
      headers: { Accept: "application/json" }
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.error || `Search failed (${response.status})`);
    }

    const results = Array.isArray(data.results) ? data.results : [];
    $("status").innerHTML = `<p><b>${results.length}</b> provider(s) found for <b>${esc(service)}</b> in <b>${esc(location)}</b>.</p>`;

    if (!results.length) {
      $("results").innerHTML = "<p>No providers found. Try a broader service or nearby city.</p>";
      return;
    }

    $("results").innerHTML = results.map((provider) => {
      const website = safeUrl(provider.website);
      const maps = safeUrl(provider.maps);
      const phone = String(provider.phone || "").replace(/[^+\d]/g, "");

      return `
        <article class="card">
          <h3>${esc(provider.name)}</h3>
          <div class="meta">${esc(provider.address || "Address unavailable")}</div>
          ${provider.distance ? `<div class="meta">Approx. ${(Number(provider.distance) / 1000).toFixed(1)} km away</div>` : ""}
          <div class="actions">
            ${phone ? `<a href="tel:${esc(phone)}">Call</a>` : ""}
            ${website ? `<a href="${esc(website)}" target="_blank" rel="noopener noreferrer">Website</a>` : ""}
            ${maps ? `<a href="${esc(maps)}" target="_blank" rel="noopener noreferrer">Map</a>` : ""}
          </div>
        </article>`;
    }).join("");
  } catch (error) {
    $("status").innerHTML = `<div class="error">${esc(error.message || "Something went wrong. Please try again.")}</div>`;
  } finally {
    $("searchBtn").disabled = false;
  }
}

$("searchBtn").addEventListener("click", searchProviders);
$("location").addEventListener("keydown", (event) => {
  if (event.key === "Enter") searchProviders();
});
$("service").addEventListener("keydown", (event) => {
  if (event.key === "Enter") searchProviders();
});
